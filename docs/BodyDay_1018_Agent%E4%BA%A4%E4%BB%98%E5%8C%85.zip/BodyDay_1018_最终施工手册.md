# BodyDay《身体的一天》· 10 月 18 日最终施工手册

> 用途：给本地 Agent 的代码级施工规范。**不是已执行报告**。本次目标是提交可验证的健康科普 H5 成品；实现与测试必须以 Agent 读取到的本地最新代码为准。日期：2026-10-18。

## 0. 基线与不可违反的约束

- 原项目：`https://github.com/MortonCheung/BodyDay`，应用根目录 `body-day/`；远端 `main` 检查到的最新提交为 `aea1669f20e87a4cc6a7e6c9d9caf83e46129f5d`（2026-10-15）。**本地可能更新，不得将远端旧提交强行覆盖本地改动。**
- 原技术：Vite 8、React 19、TypeScript 6、Three.js 0.186、R3F、Drei、`@vixotic/vanatome-react` 0.1.6；官方人体图谱 Vanatome/Z-Anatomy。原 `11` 个页面（含封面、封底）已整理于 `body-day/docs/H5_PAGE_INDEX.md`。
- 比赛组别：非医类健康科普第四组（H5 交互式）。保留 **10–20 个有真实内容、可单独打开的页面/视图，包含封面与封底**；演示视频 **≤8 分钟**、提交源程序、《作品开发文档》、学校审核推荐材料。不能通过空白或重复视图凑数。
- **紧急参赛风险**：比赛总通知规定作品未公开发表或商用，而本仓库当前在 GitHub 可公开访问。公开源码是否被组委会认定为“已公开发表”存在解释风险，应**立即向校赛负责人核实**；转为私有可能降低进一步传播，但**不会消除曾经公开的事实**。不能隐瞒或虚假声明“从未公开”。
- 保留原知识与来源、细胞模型、模型加载、错误处理；不要新建后端、登录、AI、复杂数据库、模拟生理数据、多个不兼容的人体坐标体系。
- 先创建安全分支并记录当前 `git status`、`git log`、可运行命令、测试结果；保留回滚入口。若本地有未提交文件，不得覆盖、清空、重置或 `git clean`。
- 以**可正确运行、可录屏、可交付**为最高目标。重大实验分支 60–90 分钟未通过浏览器验收就停止、回退；至少给视频/文档/提交通道留出连续 3 小时。

## 1. 需求冻结：精确行为

### 1.1 极简入口

**当前问题**：加载页有重复 BodyDay/跨尺度人体科普、三维人体标签、说明段落、来源描述及无关按钮。

**期望**：
- 页面背景为继承既有暖白/米灰风格的纯净画布，视觉中心只有一个进度条（加载阶段）。
- 加载真正完成后，**相同 DOM 外壳**原地从细长进度条平滑形变为一个正常比例按钮，文案 **「进入探索」**。不允许进度条消失后再弹出另一个独立按钮，也不允许瞬间用 `display:none` 替换。
- 点击按钮才进入工作台；未点前不能突然自动进入。加载失败时仅给简洁错误/重试，不虚构 100%。
- 进度可由 GLB `onLoadProgress` 与 `onReady` / Human Atlas `onProgress` 驱动；数值可以平滑显示，但 **100% 必须由真实 ready 信号触发**，不能定时假装加载完成。
- 正常加载界面不得展示来源、口号、长说明、操作提示、页脚；版权与声明迁入“关于”页，**不能删掉法定署名**。
- 若首屏人体数据实在过大，不要一次预载所有系统模型；明确设计最小可进入模型的 ready 门槛、后台增量加载。不可因为宣称「加载完成」实际还是空 Canvas。

状态机建议：
```
loading -> ready -> morphing -> enterable -> entering -> workbench
                  \-> error (允许重试)
```
`enterable` 的按钮可点击且键盘可达。`prefers-reduced-motion` 模式下瞬时切换。

### 1.2 顶栏与固定空间

顶部固定导航必须为 **身体 / 系统 / 器官 / 细胞 / 关于**。不得保留旧的“首页 / 人体 / 细胞 / 关于”组合及双模式按钮；既有引导教学代码可保留但不在主界面打断路线。

- “身体”回到完整人体的整体探索。
- “系统”进入系统选择的默认视图（推荐默认神经系统，不虚构独立页面），可选择其他真实可加载系统。
- “器官”进入器官选择视图（脑、心、脾为已完成重点，其他已装载且真实存在的结构可被点选）。
- “细胞”进入程序化细胞展示（神经元 / 白细胞）。
- “关于”包含真实来源、许可、模型边界、原创范围、可访问页面索引。
- 使用 `HashRouter` 维持直达链接。默认入口 `#/` 是唯一独立封面；用户点击“进入探索”后导航到 `#/body`，而不是给其他页面铺同一份空白截图。
- 顶栏选择与左侧列表应按路由同步，支持浏览器前进后退。

布局：右侧显示当前结构卡片，没有选中时只显示当前层级必要的主题简介；选中后**完全替换默认人体介绍**，避免“选中肺叶，下面却总是人体 Human Body”。左栏是当前层级的筛选与导航，中央是唯一主要 3D 舞台。左右面板应具有可滚动内容但不能导致整体场景错位。

### 1.3 滚轮展开 + 面板顺序

用户进入身体视图时：
1. 中央只见**完整人体**，左右面板在屏幕外，透明且不可点击。
2. 鼠标向下滚 / 触控板下滑：人体从组合态开始**逐渐分离**。不允许通过改变整个模型的缩放大小冒充拆解。
3. 最终状态应是器官/结构投影在同一正面二维平面上、以行列或确定性打包排列，尽量避免重叠；注意每个结构仍是可选中的三维网格，不是截图拼贴。
4. **只有展开阶段完全结束后**，继续向下滚动才触发左面板从左往右、右面板从右往左同步入场。
5. 面板入场完毕才激活结构选择；点选项目可定位到结构并更新右侧卡片。
6. 向上滚动反向执行：先收起面板，再把平面结构归位成人体。不能让两套动画互相抢相机。
7. 用户离开身体进入系统/器官/细胞时，先结束当前滚动阶段，再建立该层级自己的可视内容；不能出现人体导航和细胞模型同时占据一个 Canvas。
8. 系统/器官/细胞遵循“单个主对象 → 展开对应结构 → 面板入场 → 选中解释”的视觉语法，但**不要为了逻辑统一伪造不存在的解剖子结构**。细胞维持已核验的神经元四部件、白细胞三部件；只有具备实际几何部件的才做真实拆解，其余使用清晰的部件/关系定位。

滚动时间线使用 `progress∈[0,1]`（以下是建议值，调节以视觉验收为准）：
- `[0,0.72]` 几何拆解 `explode = smoothstep(progress/0.72)`；
- `(0.72,0.84)` 完整平面展开停留，**无面板入场**；
- `[0.84,1]` 两侧面板在同一时间轴滑入 `panel = smoothstep((progress-0.84)/0.16)`。
- 逆向滚动严格按同一轨道回放；反向没有突然弹动。

滚轮优先由工作台容器上的原生 `wheel`（`passive:false`）或 GSAP ScrollTrigger 驱动。**不要在滚动拆解期继续把同一滚轮事件交给 OrbitControls 缩放**；如果存在冲突，应在拆解期禁用 zoom/捕获 wheel，完成后允许用户按需观察。面板自身滚动事件不得误触发人体拆装。禁止给 `window` 永久全局拦截以致“关于”页不能正常滚动。

### 1.4 选中逻辑与科普卡片

- 左栏选择 / 三维直接点击，统一进入 `selectionId` 状态；调用映射更新右栏，选中结构可视觉高亮/聚焦。
- `rawSelection` 不得再显示“还没有独立科普卡片”“未编入”等防御性文字。
- 所有真正允许选中的条目都必须返回一张非空结构卡片（名称、所属系统/层级、结构类型、可核查的功能/说明、来源）。对已有权威内容的“脑、心、脾、神经元、白细胞、神经/循环/淋巴系统”优先提供详尽卡片。
- 对大量深层次模型节点，在时间不足时**基于上游解剖元数据做诚实的通用卡**：真实结构名（中文经核对者中文，未知保留英文）、所属系统、上级结构（若元数据存在）、结构类型、上游来源。**未经核验的功能不能编造；没有数据时不生成虚假的“功能”句子。** 通用卡也应是简洁有用的真实信息，不出现工程 ID、内部术语或道歉文案。
- 结构 ID、系统关联、显示状态、`rawSelection`、卡片标题必须对应同一结构；无匹配的上游节点禁止谎称“脑细胞”或“白细胞”。
- 当前结构选中时隐藏或收起旧“人体 Human Body”重复区域；取消选中后显示当前层级摘要，而不是所有页面都固定人体摘要。
- 科普卡片页面内部**不展示**冗长许可证和重复免责声明；完整版权、科普示意边界仅在“关于”页与交付材料保留。

### 1.5 人体性别中性化及缺口修复

- 目标：保留完整体表/骨盆区域轮廓，隐藏明确性别特征的细节结构；**不能从模型中直接剔除导致身体出现空洞**。
- 优先审计现有 `regional-anatomy` shell、图层设置和 `visibleLayers/alwaysVisibleIds/hiddenIds`，复核可用的原始 body shell 完整性，区分**渲染遮挡**与**原始 GLB 本身无面片**。
- 优先保留完整 body shell、降低敏感细节显著度，隐藏单独的 reproductive 器官图层。绝不删除覆盖该区的整体 body shell。
- 如果 shell 自身有缺口，只有在许可允许、坐标系与透视下可验证时，才用**中性、无解剖器官暗示的表面补片**平滑补全轮廓。若需要深入改第三方 GLB、存在坐标不兼容/透视穿帮风险，不要在最后阶段盲目植入几何；保留可用视图并记录待处理项。
- 验收必须包含正面、侧面、旋转 180°及各种缩放距离，绝不接受固定屏幕坐标的 CSS 遮挡贴片或硬切裁剪。

### 1.6 动画及文案收敛

- 所有视觉变化来自同一状态进度，使用 `GSAP`（若现有项目未装则按兼容性评估后安装）或已经具备的动画能力。不要叠加多个无状态 setTimeout/独立 keyframe。
- 主时间轴：加载条形变→按钮；人体展开→面板同步入场；选中→高亮/右卡片过渡；导航层级转换。每段动画应可逆、可中断、不会突闪/白屏。
- 删除：开屏所有口号标签/多余段落、上方“尺度/真实解剖模型”、舞台底部“拖动旋转/滚轮缩放/点击结构/ESC”、不必要的复位按钮、右面板“使用说明”“防御性声明”“统计数量/11 条路径”“未提供模型不拿别的顶替”等。
- 不得删除：真实错误提示与重试、可访问性标签（可以视觉隐藏）、模型来源的法定归属说明（保留关于页）、实际有用的科普知识与相关来源。
- 不做新视觉体系，沿用 BodyDay 暖纸色调 / 黑字 / 细线，三栏适当增加信息密度，避免霓虹大屏、装饰粒子和高度拟态。

## 2. 真正的开源利用方式与路线选择

### 路线 A（优先短时试验）：Human Atlas 原生展开引擎适配

项目：`https://github.com/ashemag/human-atlas`。代码 MIT、人体资源 BodyParts3D 4.0 为 CC BY 4.0。原生已经提供：
- `app/explosion-layout.ts`：把可见 mesh 的二维投影包围盒打包，返回每个 cell 的 x/y；
- `app/scene.tsx`：按 `state.explode∈[0,1]` 渐进移动每个真实 mesh，前期按系统空间分离、后期转为同平面布局；自带选中、相机适配、渲染状态和清理；
- `app/anatomy.ts`：系统/结构和 `SceneState` 等类型；
- `app/model-download.ts`、`app/pointer-tap.ts`：模型数据加载/点选辅助；
- `public/models/`：随源码授权分发的大体量数据（上游文档表示约 33MB 压缩几何）。
- `app/page.tsx` 是原项目完整 UI，与 BodyDay 视觉架构冲突，**不要把整页 UI 抄进去**。

**移植顺序**：
1. 单独下载/检验上游仓库与其 LICENSE、ATTRIBUTION；锁定 commit SHA，检查源码/资源及真实总大小。
2. 优先在**隔离试验分支**把 `AnatomyScene + 必需纯 TS 帮助模块 + public/models` 移入 `body-day/src/vendor/human-atlas/`（模型放 `body-day/public/vendor/human-atlas/models`），保留原有许可和出处；调整上游 `/models/` 绝对地址为 Vite `BASE_URL` 兼容路径。
3. 建一个薄适配 `HumanAtlasStage`：props 是 `explode`, `visibleSystems`, `selectedPartIds`, `onSelect`, `onLoadProgress`, `onReady`, `onError`；只映射到 Human Atlas 现有 `SceneState`，不重写 2000 多个 mesh GPU 逻辑。
4. 由于模型 ID 不同，新增 `humanAtlasBridge.ts`，只映射**人工核对**的已使用器官/系统/结构。未知部位走真实来源元数据通用卡；不能用字符串模糊匹配自动冒充匹配。
5. 仅在一个主舞台中使用一个引擎。卸载其他引擎必须释放 WebGL 资源；**严禁同一 DOM 同时渲染 Human Atlas Canvas 和 Vanatome Canvas**。细胞继续用 BodyDay 的 `CellStage`。
6. 验证两个视频级完整流程：正常人体→平面展开→选中脑/心/脾→卡片；以及从其中一个器官进入神经元/白细胞、返回工作台。若中断或兼容问题未解决，停止 A。

路线 A 的**硬止损条件**：90 分钟内未达成 `npm run build` 成功 + 正常人体和真正的平面展开 + 选中更新卡片 + 没有两个 Canvas，立即停止，回到稳定分支。不许牺牲视频时间继续“再试一下”。

### 路线 B（稳定备选）：保留 Vanatome + 明确分层

当前 `@vixotic/vanatome-react` 支持层切换、selected/parent/parent-context 隔离、focus/reset、normal/xray/ghost、真实 loading callbacks；**不支持公开 API 直接控制每个 mesh 的平面展开位置**。

如果 A 超时：
1. 保留 Vanatome 作身体/系统/器官查看器，重做入口、五层顶栏、三栏工作台、统一选中卡片、面板滑入、文字去冗余、模型取景、性别中性展示。
2. 人体“展开”仅允许用**实际可用的按图层隔离/剥离**来呈现，不能写“已完成平面几何展开”；对视觉假象须诚实标注技术状态。
3. 如果必须具备平面排列才可交付，立即报告“当前方案不支持”，避免深层次修改 npm 库的内部模型引用或用截屏冒充真实网格。
4. 对 10 月 18 日交付而言，运行稳定的 B 好于未完成而崩溃的 A。录像优先选择实际稳定的功能。

**最重要判断**：不要混用 Z-Anatomy/Vanatome 的结构 ID 与 BodyParts3D/Human Atlas 的 geometry ID，二者不是同一套 atlas。

## 3. 代码目录与变更合同

远端存在的确定文件（施工前核对本地）：
```
body-day/
  package.json
  src/app/AppRouter.tsx
  src/app/AppShell.tsx
  src/app/resolveView.ts
  src/app/routes.ts
  src/app/AppProviders.tsx
  src/features/workbench/ExploreWorkbench.tsx
  src/features/workbench/StructureRail.tsx
  src/features/workbench/KnowledgePaper.tsx
  src/features/workbench/WelcomeOverlay.tsx
  src/features/workbench/GuidePanel.tsx
  src/features/workbench/workbench.css
  src/three/AtlasStage.tsx
  src/three/CellStage.tsx         # 施工前核对准确文件名/路径
  src/services/atlas.ts
  src/domain/                  # 实体、关系、来源、课程
  src/features/about/AboutPage.tsx
  docs/H5_PAGE_INDEX.md
delivery/
  source-archive.zip
  docs/作品开发文档.md
  docs/作品开发文档.docx
  demo/DEMO_VIDEO_SCRIPT.md
  DELIVERY_CHECKLIST.md
```

推荐新增（可按现有结构合并，不强制机械创建）：
```
src/features/entry/EntryGate.tsx
src/features/entry/entry.css
src/features/workbench/useExplodeTimeline.ts
src/features/workbench/useScrollProgress.ts
src/features/workbench/SelectionDetails.tsx
src/domain/structureCard.ts
src/three/humanAtlasBridge.ts       # 只有路线 A
src/vendor/human-atlas/             # 只有路线 A，须含许可/署名
src/features/workbench/__tests__/  # 测试
```

### 3.1 `EntryGate` 必须用同节点形变

建议 UI / 类型契约（结构示意，适配本地真实 ready 信号后再使用）：

```tsx
type GatePhase = 'loading' | 'ready' | 'morphing' | 'enterable' | 'error';

type Props = {
  actualProgress: number; // 0..100，来自真实模型加载
  modelReady: boolean;    // 仅在模型资源与 Canvas 确认就绪后为 true
  error?: string | null;
  onEnter: () => void;
  onRetry: () => void;
};

function EntryGate({ actualProgress, modelReady, error, onEnter, onRetry }: Props) {
  const phase: GatePhase = error ? 'error' : modelReady ? 'enterable' : 'loading';
  const ready = phase === 'enterable';
  return (
    <main className="bd-entry" aria-label="作品入口">
      <button
        type="button"
        className="bd-entry__morph"
        data-ready={ready}
        disabled={!ready}
        onClick={onEnter}
        aria-label={ready ? '进入探索' : '正在加载模型'}
      >
        <span className="bd-entry__fill"
              style={{ transform: `scaleX(${Math.max(0, Math.min(actualProgress, 100)) / 100})` }} />
        <span className="bd-entry__buttonLabel">{ready ? '进入探索' : ''}</span>
      </button>
      {error ? <button type="button" onClick={onRetry}>重试</button> : null}
    </main>
  );
}
```

这里**必须保持同一个 `<button>` DOM 节点**，通过 `data-ready` 在 CSS 中变更宽、高、背景、边框半径、进度填充层的透明度与文字透明度，而不是先删除 div 再增加 button。
```css
.bd-entry { min-height: 100dvh; display:grid; place-items:center; background:var(--bd-paper,#f7f5f1); }
.bd-entry__morph { position:relative; width:min(240px,60vw); height:3px; border:0; border-radius:2px; overflow:hidden; background:#dedbd5; transition:width 620ms cubic-bezier(.22,1,.36,1),height 620ms cubic-bezier(.22,1,.36,1),border-radius 620ms cubic-bezier(.22,1,.36,1),background 620ms; }
.bd-entry__morph[data-ready="true"] { width:148px; height:44px; border-radius:8px; cursor:pointer; background:#201e1b; }
.bd-entry__fill { position:absolute; inset:0; transform-origin:left; background:#44403a; transition:transform 120ms linear, opacity 280ms; }
.bd-entry__morph[data-ready="true"] .bd-entry__fill { opacity:0; }
.bd-entry__buttonLabel { position:relative; z-index:1; color:white; opacity:0; transition:opacity 200ms ease 360ms; font-size:14px; }
.bd-entry__morph[data-ready="true"] .bd-entry__buttonLabel { opacity:1; }
@media(prefers-reduced-motion:reduce) { .bd-entry__morph,.bd-entry__fill,.bd-entry__buttonLabel { transition:none; } }
```
**注意**：上面 phase 是最小接口展示；在生产中需确立 `ready → morphing → enterable` 过渡防止按钮仍处于 3px 高就可点。实现时用 `transitionend` 或同一 GSAP timeline 的 `onComplete` 标记真正可点，不允许根据虚假计时让 progress 到 100。

### 3.2 `useScrollProgress`/`useExplodeTimeline`

按路线 A 映射 `explode` 到 Human Atlas `SceneState.explode`。工作台滚动事件和三维交互解耦，避免 React 每个 wheel event 使整个三维重新挂载。

```ts
export type ExplodeState = { progress: number; explode: number; panel: number; interactive: boolean };
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const smooth = (v: number) => { const t=clamp01(v); return t*t*(3-2*t); };

export function deriveExplodeState(progress: number): ExplodeState {
  const p = clamp01(progress);
  return {
    progress:p,
    explode:smooth(p/0.72),
    panel:smooth((p-0.84)/0.16),
    interactive:p>=0.98,
  };
}
```

建议 `useScrollProgress` 实现要点：
- 将 `progress` 放在一个受控 store/ref，并通过 `requestAnimationFrame` 聚合更新；不在滚轮每像素重新创建 WebGL 组件。
- 在用户允许展开的舞台上注册：`element.addEventListener('wheel', onWheel, { passive:false });`；`onWheel` 仅当事件确实属于舞台且不在左右 `.bd-wb-rail/.bd-wb-paper` 时 `preventDefault()`，按 `deltaY` 映射进度。
- `deltaMode` 不是像素时做单位归一；每帧总量设最大限速以免单次滑动跨越三个阶段，触控板滚动需顺畅。
- 键盘 PageDown/PageUp/ArrowDown/ArrowUp 给无滚轮环境可用入口；手机使用垂直触摸手势（不得与横向拖动旋转冲突）。
- 右栏文本滚动优先给右栏自己处理；已经选中正在阅读时，不要让左/右栏滚动反向组装模型。
- `Esc`/点空白只清空选中，**不要**强制逆向跑完整个滚动时间线。
- `p<.84` 面板用 `visibility:hidden` + `pointer-events:none` 避免无法看见但键盘 Tab 仍可达的隐形项；进入后渐显并恢复可达性。
- 如果使用 GSAP ScrollTrigger，采用 `pin:true, scrub:true` 的单 timeline 统一控制，并在 component cleanup 时 `kill`；不要同时使用手写 `wheel` 积分和 ScrollTrigger 改同一个 `progress`。
- CSS 面板入场绑定 **同一 panel 值**：
```css
.bd-wb-rail { transform:translate3d(var(--rail-offset, -105%),0,0); }
.bd-wb-paper { transform:translate3d(var(--paper-offset, 105%),0,0); }
```
实际由单个 `panel` 数值在 requestAnimationFrame 内更新 `.bd-workbench` 的 CSS 变量：`--rail-offset = (-105 * (1-panel)) + "%"`；`--paper-offset = (105 * (1-panel)) + "%"`。避免依赖不稳定的 CSS 百分比乘法语法；或者直接用同一 GSAP timeline 绑定两个 `xPercent`。只做 transform，避免 layout thrash。不要直接在 JSX 里对左右两侧分别使用不同的动画时长。
- 如果直接对原 `VanatomeViewer` 附加 `explode` props 会 TS 报错；**不要这么做**，该公开接口没有该能力。

### 3.3 顶栏 `AppShell` / 路由

原 `AppShell.tsx` 顶栏现在是「首页/人体/细胞/关于」并且还有「自由探索/引导教学」。调整为：
```ts
const NAV = [
 { label:'身体', to:ROUTES.body, scale:'body' },
 { label:'系统', to:ROUTES.system('nervous-system'), scale:'system' },
 { label:'器官', to:ROUTES.organ('brain'), scale:'organ' },
 { label:'细胞', to:ROUTES.cell('neuron'), scale:'cell' },
 { label:'关于', to:ROUTES.about, scale:'about' },
] as const;
```
以 `resolveView(location.pathname)` 决定选中状态，不要把点击“系统”的默认路由误标为全部系统都有完整科普专题。导航中不要多余的“首页”按钮；入口 `#/` 作为可通过 Logo 回到的独立入口。
- `AppProviders` 保留旧偏好兼容但不再向主 Header 露出双模式。
- `ExploreWorkbench` 拆出 `Stage`, `LeftSidebar`, `RightDetails` 子组件；不重新搭全新 Router。
- 顶栏高度和两侧栏宽度使用 CSS 变量，中心模型在 1440×900 充分展示；窄屏可变为抽屉/上下布局，不让主体不可见。

### 3.4 `KnowledgePaper` 改造合同

现有代码已确认：
- `src/features/workbench/KnowledgePaper.tsx` 在 `rawSelection` 分支第 ~93 行有“尚未建立独立科普卡片”；
- `entity` 区块始终在后面展示默认 `Human Body` 卡；
- 底部固定“科学边界”块；顶部还有 ScaleBadge/Clock/ScaleLine。
全部收敛：
```tsx
const active = selectedEntity ?? (rawSelection ? structureCardFromAtlas(rawSelection, metadata) : entity);
return (
  <aside className="bd-wb-paper" aria-label="当前结构信息">
    {active
      ? <SelectionDetails key={active.id} structure={active} />
      : <CurrentLevelIntro scale={scale} />}
  </aside>
);
```
真实数据契约（**建议结构，需接上游元数据**）：
```ts
type StructureCard = {
  id:string; name:string; systemName:string;
  level:'body'|'system'|'organ'|'cell'|'part'|'structure';
  parentName?:string; functionText?:string; locationText?:string;
  verifiedFacts?:string[]; sourceIds:string[]; sourceKind:'curated'|'atlas-metadata';
};
```
优先命中 `ENTITY_MAP` 已核对卡片；未命中时从真实 `StructureSelection + atlas.structures` 生成通用结构卡。如果元数据没有功能，不显示该字段而不是造答案；通用卡至少显示结构名、结构类别、所属系统和图谱来源。
- `StructureRail` 只展示对应层级必要操作，不展现“浏览/专题”这种工程状态，不暴露内部 ID；
- 带信息量的“所属层级/位于哪个系统/相关作用”胜过“本项目支持 11 类…”；
- 文案里的医疗风险/版权完整说明放在关于页，但任何会导致实质性误解的科学限定应保留在具体内容中。
- 保留来源编号和可打开的真实来源链接，但可放在卡片末尾折叠区。

### 3.5 稳定视觉与隐藏项

改 `ExploreWorkbench.tsx` 删除 `.bd-wb-hud`、`.bd-wb-hud-bottom` 中对操作冗余说明的可见输出；`.bd-wb-stage__actions` 复位按钮如果不影响操作可删（保留键盘或其他可靠重置手段）；`KnowledgePaper` 科学边界区改关于页；`AppShell` 删除双模式按钮；`WelcomeOverlay` 整体应被 EntryGate 所替代。**不要删除具体医学科普卡/来源/免责声明的数据本身。**

`AtlasStage` 当前 Vanatome 可用字段：`selectedId`、`isolation`、`visibleLayers`、`alwaysVisibleIds`、`displayMode`、`focusRequestKey`、`resetViewKey`、`focusPadding`、`cameraAnimationDuration`、`appearance`、`onLoadProgress`、`onReady`。
- 将 `onLoadProgress` / `onReady` 真实连到 EntryGate，注意多 bundle 加载进度的单一源与最终完成判断；
- 对白屏问题额外检查：目标结构所属 bundle 是否就绪、层过滤是否隐藏结构、`onFocusRejected` 是否被调用；必须以实际真实浏览器截图为准；
- **不要**向上游 `VanatomeViewer` 传并不存在的 `explode`、`onMeshTransform` 或直接访问私有 refs。

## 4. 实施顺序、工时预算与阶段验收

| Phase | 截止前最高工时 | 要做 | 通过条件 | 失败处理 |
|---|---:|---|---|---|
| 0 · 基线 | 15 分钟 | 保存 Git 状态、检查本地新分支、保留原 build 与截图 | 原功能可运行、已知回滚提交 | 未通过先修环境 |
| 1 · 入口 | 25–35 分钟 | 清空装饰 + 真实进度 + 同节点形变 + 点击进入 | 只有一个控件，100% 真 ready，按钮原地平滑出现 | 保留简单稳定按钮 |
| 2 · 布局与导航 | 25–40 分钟 | 五项顶栏、三栏、删除冗余文案和干扰按钮 | 5 项可直达，内容不遮挡 | 保留旧 CSS 网格骨架 |
| 3 · 展开引擎 | **最多 90 分钟** | 试 Human Atlas 真实平面拆解、回退时保留 Vanatome | 真实网格完整-平面可逆 + 选中 + 无双 Canvas + build 通过 | 一次回滚，切 B，明确未实现 |
| 4 · 信息卡 | 30–45 分钟 | 优先结构卡 + 元数据通用卡 + 动态替换旧摘要 | 随机点 20 个可选节点，无防御文案，无空白卡 | 暂时缩小可选条目范围，不造数据 |
| 5 · 人体中性化 | 20–30 分钟 | 先检查隐藏导致的空洞、恢复中性轮廓 | 正/侧/旋转均无显著下半身缺口 | 不冒险重做 GLB |
| 6 · 验收和交付 | **必须保留 ≥3 小时** | 全链路浏览器测试、录屏、同步文件、学校平台 | 完整提交证明 | 优先视频/开发文档/平台 |

独立提交每一阶段，不要一个大 commit 混合所有内容。Phase 3 属高风险，不允许把其失败混进 Phase 1、2 已通过成果。

## 5. 强制测试矩阵

1. **入口**：首次无缓存进入，进度不提前跳 100；进度条不闪、不换节点形变成按钮；点击进入，返回入口可用；错误可重试。
2. **三维**：人体完整可见；神经、循环、淋巴各有正确模型；脑、心、脾主体可见且不黑屏；神经元、白细胞完整进入画布（原截图曾有大脑/神经系统空白、白细胞过大问题）。
3. **滚轮**：向下逐帧拆解，展平后面板才进，左右同时到位；向上严格逆向；滚轮不会意外缩放导致模型消失；轨迹不因单帧大 delta 跳过。
4. **选择**：人体左肺上叶 `Superior lobe of left lung`、大脑、心脏、脾脏、一个陌生英文结构、神经元胞体、白细胞细胞核均能出非空卡；无“本作品尚未编入科普卡片”。
5. **层级**：身体/系统/器官/细胞/关于导航正确；浏览器回退与刷新正确；逐级进入、返回均保持层级语义。
6. **性别中性化**：正面、背面、侧面旋转、不同缩放距离均无明显空洞、突兀贴片或明确的性别器官突出。
7. **性能**：1440×900、1280×720 和至少一个 390×844 响应视口；过渡顺畅，无控制台 runtime error、持续内存泄漏、WebGL 上下文重复堆积。
8. **工程门禁**：`npm run build`、`npm run lint`、`npm run test`，已有 41 测试不能无理由删除，新增入场时间线/卡片生成/滚动阶段测试。
9. **材料**：源文件压缩包重新生成并解压独立运行验证；`delivery/docs/作品开发文档.docx` 的截图、功能描述真实同步；≤8 分钟演示视频确实存在，镜头路线不虚构；11 页名单与实际路由一致。
10. **版权**：第三方代码 MIT/LICENSE、BodyParts3D CC BY 4.0、Vanatome/Z-Anatomy CC BY-SA 4.0 各自注明适用材料；作品版权声明不把上游数据据为原创。

## 6. 交付物、验收报告与停止条件

最终需要 Agent 实际生成或更新（按实有文件）：
- 可运行的 `body-day/` 源码与必要版权文件、`package-lock.json`；
- `delivery/source-archive.zip` 与源码副本，且**与最后提交严格一致**；
- `delivery/demo/DEMO_VIDEO_SCRIPT.md` 与实际页面一致，录屏是用户负责的真实视频；如果 Agent 能在本机真实 GPU 环境下生成可靠视频，则可辅助，但绝不能以未录制宣称已完成；
- 《作品开发文档》Word/PDF：需求分析、概要设计、详细设计、测试、安装使用、项目总结/未来升级；截图改为最终真实 UI，不用旧 11 页截图冒充新版；学校公章由校方办理；
- `delivery/DELIVERY_CHECKLIST.md`、`delivery/FINAL_DELIVERY_REPORT.md`、`delivery/H5_PAGE_INDEX.md` 更新；
- `FINAL_HANDOFF_20261018.md`：最新 commit SHA，真实 build/test，逐页通过/失败，A 或 B 分支选择，哪些功能降级，尚需人工完成哪些事；所有未完成项清晰标红。

最后由用户/校赛负责人在 2026-10-18 截止前完成平台申报、校赛审核推荐；学校的开发文档及汇总表等盖章报送按赛事文档要求另行完成。平台提交后保存成功截图和回执。

**立即停止开发**当出现以下任一情况：距离必须提交/录屏时间不足 3 小时；路线 A 超过 90 分钟未通过全部核心验收；新修改使三维主线路崩溃并且 20 分钟内不能定位；无法提供可靠医学来源或素材授权。此时以最新稳定可运行版本交付，不再扩功能。

## 7. 本次不做（绝对禁止）

- 不搭新项目或整体换框架；不重写 Human Atlas 的 2,234 网格 GPU 渲染核心；
- 不复制 Human Atlas 全站 UI 仅换色就声称独立原创；
- 不用外部未知版权的精美模型“先上再说”；不去掉关于页的知识产权信息；
- 不把 2D 贴图冒充真实可选中的三维平面拆解；
- 不生成假 100% 进度、假 FPS、假真机测试、假截图或假演示视频；
- 不擅自把原源码路径和提交历史删掉、不强推覆盖远端；
- 不再加入 AI 问答、诊疗决策、登录、服务器、社交、花哨动效；
- 不为追求复杂而让评审无法在 30 秒内看懂如何进入和探索。

## 8. 供施工者核对的来源

- BodyDay 源码仓库：https://github.com/MortonCheung/BodyDay
- Human Atlas：https://github.com/ashemag/human-atlas
  - 真正二维投影打包：`app/explosion-layout.ts`
  - 结构平面运动：`app/scene.tsx` 中 `createExplosionLayout`、`state.explode`、`offsets` 等
  - 许可：`LICENSE` 和 `public/models/` 对应 `ATTRIBUTION.md`
- Vanatome：https://github.com/vixotic/Vanatome
  - 公开 React 查看器文档：`packages/react/README.md`
- GSAP ScrollTrigger：https://gsap.com/docs/v3/Plugins/ScrollTrigger/
- 大赛附件 1：非医类健康科普赛道，10 月 18 日提交截止、H5 页面 10–20、演示视频≤8分、源程序、《作品开发文档》、学校审核推荐与盖章报送。
